import TeamPage from "../_components/module/team/TeamPage";

export default function page() {
  return (
    <>
      <TeamPage />
    </>
  );
}
