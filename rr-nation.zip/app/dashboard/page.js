import DashboardOverview from "./_components/module/Overview/DashboardOverview";

export default function DashboardOverviewPage() {
  return (
    <DashboardOverview/>
  )
}
