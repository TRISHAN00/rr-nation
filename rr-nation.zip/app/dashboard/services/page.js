import ServicesPage from "../_components/module/services/ServicesPage";

export default function page() {
  return (
    <><ServicesPage/></>
  )
}
