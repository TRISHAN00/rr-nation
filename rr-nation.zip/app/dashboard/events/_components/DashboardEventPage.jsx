
export default function DashboardEventPage() {
  return (
    <div>DashboardEventPage</div>
  )
}
