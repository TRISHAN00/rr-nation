import GalleryPage from "../_components/module/gallery/GalleryPage";

export default function page() {
  return (
    <>
      <GalleryPage />
    </>
  );
}
