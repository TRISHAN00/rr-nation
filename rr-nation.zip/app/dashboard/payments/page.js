import PaymentSettingsPage from "../_components/module/payment/PaymentSettingsPage";

export default function page() {
  return (
    <>
      <PaymentSettingsPage />
    </>
  );
}
