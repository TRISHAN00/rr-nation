import SettingsPage from "../_components/module/settings/SettingsPage";

export default function page() {
  return (
    <>
      <SettingsPage />
    </>
  );
}
