import RegistrationsPage from "../_components/module/registrations/RegistrationsPage";

export default function page() {
  return (
    <><RegistrationsPage/></>
  )
}
