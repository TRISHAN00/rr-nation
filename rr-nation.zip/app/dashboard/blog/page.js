import BlogPage from "../_components/module/blog/BlogPage";

export default function page() {
  return (
    <><BlogPage/></>
  )
}
