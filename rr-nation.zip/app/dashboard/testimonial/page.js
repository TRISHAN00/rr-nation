import TestimonialsPage from "../_components/module/testimonial/TestimonialsPage";

export default function page() {
  return (
    <>
      <TestimonialsPage />
    </>
  );
}
