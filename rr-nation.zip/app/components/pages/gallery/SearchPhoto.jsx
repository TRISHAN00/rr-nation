export default function SearchPhoto() {
  return <div>SearchPhoto</div>;
}
