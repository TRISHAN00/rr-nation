
export default function BannerPagination() {
  return (
     <div className="custom-pagination absolute left-10 w-10  justify-center items-center top-1/2 flex flex-col gap-5 z-20" />
  )
}
