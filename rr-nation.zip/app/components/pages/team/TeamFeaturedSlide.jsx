
export default function TeamFeaturedSlide() {
  return (
    <div>FeaturedTeamSlide</div>
  )
}
