
export default function UserRegistrationForm() {
  return (
    <div>UserRegistrationForm</div>
  )
}
