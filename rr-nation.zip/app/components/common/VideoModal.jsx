
export default function VideoModal() {
  return (
    <div>VideoModal</div>
  )
}
