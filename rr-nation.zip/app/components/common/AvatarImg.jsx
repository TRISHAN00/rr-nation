
export default function AvatarImg() {
  return (
    <div>AvatarImg</div>
  )
}
